// export const AVAILABLE_SERVICES = [
//   {
//     id: "ef",
//     name: "nextdoor",
//   },
//   {
//     id: "rx",
//     name: "sheerid",
//   },
//   {
//     id: "xb",
//     name: "rummyola",
//   },
//   {
//     id: "wf",
//     name: "yandexgo",
//   },
//   {
//     id: "et",
//     name: "clubhouse",
//   },
//   {
//     id: "sg",
//     name: "ozon",
//   },
//   {
//     id: "fu",
//     name: "snapchat",
//   },
//   {
//     id: "kq",
//     name: "fotocasa",
//   },
//   {
//     id: "pm",
//     name: "aol",
//   },
//   {
//     id: "bp",
//     name: "gofundme",
//   },
//   {
//     id: "vd",
//     name: "betfair",
//   },
//   {
//     id: "wv",
//     name: "ais",
//   },
//   {
//     id: "qd",
//     name: "taobao",
//   },
//   {
//     id: "ub",
//     name: "uber",
//   },
//   {
//     id: "ev",
//     name: "picpay ",
//   },
//   {
//     id: "mq",
//     name: "gmng",
//   },
//   {
//     id: "jm",
//     name: "mzadqatar",
//   },
//   {
//     id: "bj",
//     name: "вита экспресс",
//   },
//   {
//     id: "ds",
//     name: "discord",
//   },
//   {
//     id: "zv",
//     name: "digikala",
//   },
//   {
//     id: "po",
//     name: "premium.one",
//   },
//   {
//     id: "ry",
//     name: "mcdonalds",
//   },
//   {
//     id: "lo",
//     name: "oppo",
//   },
//   {
//     id: "oz",
//     name: "poshmark",
//   },
//   {
//     id: "uj",
//     name: "сhampionсasino",
//   },
//   {
//     id: "iz",
//     name: "global24",
//   },
//   {
//     id: "ax",
//     name: "crefisamais",
//   },
//   {
//     id: "mn",
//     name: "rrsa",
//   },
//   {
//     id: "ol",
//     name: "kazanexpress",
//   },
//   {
//     id: "od",
//     name: "fwdmax",
//   },
//   {
//     id: "nr",
//     name: "tosla",
//   },
//   {
//     id: "mr",
//     name: "fastmail",
//   },
//   {
//     id: "pl",
//     name: "perekrestok",
//   },
//   {
//     id: "su",
//     name: "loco",
//   },
//   {
//     id: "qs",
//     name: "мирзнакомств",
//   },
//   {
//     id: "rz",
//     name: "easypay",
//   },
//   {
//     id: "xj",
//     name: "сбермаркет",
//   },
//   {
//     id: "tz",
//     name: "лейка",
//   },
//   {
//     id: "wa",
//     name: "whatsapp",
//   },
//   {
//     id: "rc",
//     name: "skype",
//   },
//   {
//     id: "ye",
//     name: "zaleycash",
//   },
//   {
//     id: "cw",
//     name: "paddypower",
//   },
//   {
//     id: "ha",
//     name: "my11circle",
//   },
//   {
//     id: "tw",
//     name: "twitter",
//   },
//   {
//     id: "ig",
//     name: "instagram",
//   },
//   {
//     id: "kx",
//     name: "vivo",
//   },
//   {
//     id: "nq",
//     name: "trip",
//   },
//   {
//     id: "ct",
//     name: "кухнянарайоне",
//   },
//   {
//     id: "ks",
//     name: "hirect",
//   },
//   {
//     id: "au",
//     name: "haraj",
//   },
//   {
//     id: "bx",
//     name: "dosi",
//   },
//   {
//     id: "qc",
//     name: "праймериз 2020",
//   },
//   {
//     id: "eu",
//     name: "livescore",
//   },
//   {
//     id: "ts",
//     name: "paypal",
//   },
//   {
//     id: "aq",
//     name: "glovo",
//   },
//   {
//     id: "nb",
//     name: "верный",
//   },
//   {
//     id: "di",
//     name: "loanflix",
//   },
//   {
//     id: "ww",
//     name: "bip",
//   },
//   {
//     id: "fq",
//     name: "контур",
//   },
//   {
//     id: "mu",
//     name: "mymusictaste",
//   },
//   {
//     id: "ue",
//     name: "onet",
//   },
//   {
//     id: "md",
//     name: "банки",
//   },
//   {
//     id: "el",
//     name: "bisu",
//   },
//   {
//     id: "le",
//     name: "e bike gewinnspiel",
//   },
//   {
//     id: "bl",
//     name: "bigo live",
//   },
//   {
//     id: "cs",
//     name: "agridevelop",
//   },
//   {
//     id: "ae",
//     name: "myglo",
//   },
//   {
//     id: "gg",
//     name: "pagsmile",
//   },
//   {
//     id: "ck",
//     name: "bereal",
//   },
//   {
//     id: "yw",
//     name: "grindr",
//   },
//   {
//     id: "mt",
//     name: "steam",
//   },
//   {
//     id: "ai",
//     name: "celebe",
//   },
//   {
//     id: "rt",
//     name: "hily",
//   },
//   {
//     id: "gp",
//     name: "ticketmaster",
//   },
//   {
//     id: "ic",
//     name: "jogo",
//   },
//   {
//     id: "rj",
//     name: "детский мир",
//   },
//   {
//     id: "yu",
//     name: "xiaomi",
//   },
//   {
//     id: "uh",
//     name: "yubo",
//   },
//   {
//     id: "cb",
//     name: "bazos",
//   },
//   {
//     id: "fz",
//     name: "kfc",
//   },
//   {
//     id: "sb",
//     name: "lamoda",
//   },
//   {
//     id: "vt",
//     name: "budget4me",
//   },
//   {
//     id: "tm",
//     name: "akulaku",
//   },
//   {
//     id: "dv",
//     name: "nobroker",
//   },
//   {
//     id: "zb",
//     name: "freenow",
//   },
//   {
//     id: "sf",
//     name: "sneakersnstuff",
//   },
//   {
//     id: "tc",
//     name: "rambler",
//   },
//   {
//     id: "bt",
//     name: "alfa",
//   },
//   {
//     id: "dq",
//     name: "icecasino",
//   },
//   {
//     id: "yl",
//     name: "yalla",
//   },
//   {
//     id: "qr",
//     name: "mega",
//   },
//   {
//     id: "ms",
//     name: "novaposhta",
//   },
//   {
//     id: "xf",
//     name: "lightchat",
//   },
//   {
//     id: "fx",
//     name: "pgbonus",
//   },
//   {
//     id: "fm",
//     name: "touchance",
//   },
//   {
//     id: "az",
//     name: "citybase",
//   },
//   {
//     id: "zk",
//     name: "deliveroo",
//   },
//   {
//     id: "os",
//     name: "dhani",
//   },
//   {
//     id: "aw",
//     name: "taikang",
//   },
//   {
//     id: "gm",
//     name: "mocospace",
//   },
//   {
//     id: "vm",
//     name: "okcupid",
//   },
//   {
//     id: "jx",
//     name: "swiggy",
//   },
//   {
//     id: "jr",
//     name: "самокат",
//   },
//   {
//     id: "dz",
//     name: "dominos pizza",
//   },
//   {
//     id: "yx",
//     name: "jtexpress",
//   },
//   {
//     id: "tu",
//     name: "lyft",
//   },
//   {
//     id: "uk",
//     name: "airbnb",
//   },
//   {
//     id: "cu",
//     name: "炙热星河",
//   },
//   {
//     id: "sz",
//     name: "pivko24",
//   },
//   {
//     id: "ly",
//     name: "olacabs",
//   },
//   {
//     id: "dr",
//     name: "openai",
//   },
//   {
//     id: "vw",
//     name: "coinfield",
//   },
//   {
//     id: "eb",
//     name: "voltz",
//   },
//   {
//     id: "qm",
//     name: "rosakhutor",
//   },
//   {
//     id: "ra",
//     name: "keypay",
//   },
//   {
//     id: "lz",
//     name: "things",
//   },
//   {
//     id: "tq",
//     name: "swvl",
//   },
//   {
//     id: "kv",
//     name: "rush",
//   },
//   {
//     id: "ur",
//     name: "mydailycash",
//   },
//   {
//     id: "uy",
//     name: "meliuz",
//   },
//   {
//     id: "nt",
//     name: "sravni",
//   },
//   {
//     id: "up",
//     name: "magnolia",
//   },
//   {
//     id: "xe",
//     name: "galaxychat",
//   },
//   {
//     id: "er",
//     name: "kwork",
//   },
//   {
//     id: "io",
//     name: "здравсити",
//   },
//   {
//     id: "tg",
//     name: "telegram",
//   },
//   {
//     id: "sx",
//     name: "crowdtap",
//   },
//   {
//     id: "gh",
//     name: "gyftr",
//   },
//   {
//     id: "ud",
//     name: "disney hotstar",
//   },
//   {
//     id: "hm",
//     name: "globus",
//   },
//   {
//     id: "ep",
//     name: "temu",
//   },
//   {
//     id: "rq",
//     name: "aptekiplus",
//   },
//   {
//     id: "sw",
//     name: "ncsoft",
//   },
//   {
//     id: "fg",
//     name: "indianoil",
//   },
//   {
//     id: "gq",
//     name: "freelancer",
//   },
//   {
//     id: "ij",
//     name: "revolut",
//   },
//   {
//     id: "du",
//     name: "aubank",
//   },
//   {
//     id: "si",
//     name: "cita previa",
//   },
//   {
//     id: "zu",
//     name: "bigc",
//   },
//   {
//     id: "xx",
//     name: "joyride",
//   },
//   {
//     id: "dh",
//     name: "ebay",
//   },
//   {
//     id: "fv",
//     name: "vidio",
//   },
//   {
//     id: "nh",
//     name: "allobank",
//   },
//   {
//     id: "og",
//     name: "okko",
//   },
//   {
//     id: "zg",
//     name: "setel",
//   },
//   {
//     id: "aj",
//     name: "oneaset",
//   },
//   {
//     id: "lp",
//     name: "algida",
//   },
//   {
//     id: "nw",
//     name: "ximalaya",
//   },
//   {
//     id: "jh",
//     name: "pingpong",
//   },
//   {
//     id: "ob",
//     name: "onlinerby",
//   },
//   {
//     id: "kg",
//     name: "freechargeapp",
//   },
//   {
//     id: "kr",
//     name: "eyecon",
//   },
//   {
//     id: "ou",
//     name: "gabi",
//   },
//   {
//     id: "hn",
//     name: "1688",
//   },
//   {
//     id: "yp",
//     name: "payzapp",
//   },
//   {
//     id: "mc",
//     name: "michat",
//   },
//   {
//     id: "bq",
//     name: "adani",
//   },
//   {
//     id: "bb",
//     name: "lazypay",
//   },
//   {
//     id: "we",
//     name: "drugvokrug",
//   },
//   {
//     id: "nk",
//     name: "gittigidiyor",
//   },
//   {
//     id: "pj",
//     name: "podeli",
//   },
//   {
//     id: "am",
//     name: "amazon",
//   },
//   {
//     id: "xc",
//     name: "synottip",
//   },
//   {
//     id: "kj",
//     name: "yappy",
//   },
//   {
//     id: "gw",
//     name: "callapp",
//   },
//   {
//     id: "np",
//     name: "siply",
//   },
//   {
//     id: "qt",
//     name: "moneyсontrol",
//   },
//   {
//     id: "yz",
//     name: "около",
//   },
//   {
//     id: "lb",
//     name: "mailru group",
//   },
//   {
//     id: "px",
//     name: "nifty",
//   },
//   {
//     id: "sq",
//     name: "kucoinplay",
//   },
//   {
//     id: "il",
//     name: "iqos",
//   },
//   {
//     id: "pw",
//     name: "sellmonitor",
//   },
//   {
//     id: "gv",
//     name: "humta",
//   },
//   {
//     id: "zf",
//     name: "ontaxi",
//   },
//   {
//     id: "tk",
//     name: "мвидео",
//   },
//   {
//     id: "rd",
//     name: "lenta",
//   },
//   {
//     id: "hy",
//     name: "ininal",
//   },
//   {
//     id: "um",
//     name: "belwest",
//   },
//   {
//     id: "td",
//     name: "chaingefinance",
//   },
//   {
//     id: "kb",
//     name: "kufarby",
//   },
//   {
//     id: "vq",
//     name: "ladymaria",
//   },
//   {
//     id: "rp",
//     name: "hamrahaval",
//   },
//   {
//     id: "ld",
//     name: "cashmine",
//   },
//   {
//     id: "sn",
//     name: "olx",
//   },
//   {
//     id: "ew",
//     name: "nike",
//   },
//   {
//     id: "wt",
//     name: "izi",
//   },
//   {
//     id: "pd",
//     name: "ifood",
//   },
//   {
//     id: "zl",
//     name: "airtel",
//   },
//   {
//     id: "te",
//     name: "efood",
//   },
//   {
//     id: "ym",
//     name: "youla.ru",
//   },
//   {
//     id: "ki",
//     name: "99app",
//   },
//   {
//     id: "fe",
//     name: "cliqq",
//   },
//   {
//     id: "hw",
//     name: "alipay/alibaba",
//   },
//   {
//     id: "ao",
//     name: "uu163",
//   },
//   {
//     id: "ys",
//     name: "zcity",
//   },
//   {
//     id: "ng",
//     name: "funpay",
//   },
//   {
//     id: "sy",
//     name: "brahma",
//   },
//   {
//     id: "sm",
//     name: "yowin",
//   },
//   {
//     id: "ot",
//     name: "any other",
//   },
//   {
//     id: "hg",
//     name: "switips",
//   },
//   {
//     id: "sa",
//     name: "agibank",
//   },
//   {
//     id: "jw",
//     name: "br777",
//   },
//   {
//     id: "ko",
//     name: "adakami",
//   },
//   {
//     id: "xl",
//     name: "wmaraci",
//   },
//   {
//     id: "ca",
//     name: "supers",
//   },
//   {
//     id: "qh",
//     name: "oriflame",
//   },
//   {
//     id: "zx",
//     name: "communitygaming",
//   },
//   {
//     id: "iu",
//     name: "bykea",
//   },
//   {
//     id: "go",
//     name: "google",
//   },
//   {
//     id: "iv",
//     name: "inboxlv",
//   },
//   {
//     id: "gb",
//     name: "youstar",
//   },
//   {
//     id: "hf",
//     name: "cleartrip",
//   },
//   {
//     id: "xr",
//     name: "tango",
//   },
//   {
//     id: "lm",
//     name: "farpost",
//   },
//   {
//     id: "ir",
//     name: "chispa",
//   },
//   {
//     id: "uf",
//     name: "eneba",
//   },
//   {
//     id: "xv",
//     name: "wish",
//   },
//   {
//     id: "iw",
//     name: "mylavash",
//   },
//   {
//     id: "rs",
//     name: "lotus",
//   },
//   {
//     id: "ip",
//     name: "burger king",
//   },
//   {
//     id: "op",
//     name: "miratorg",
//   },
//   {
//     id: "ss",
//     name: "hezzl",
//   },
//   {
//     id: "oc",
//     name: "dealshare",
//   },
//   {
//     id: "qp",
//     name: "максавит",
//   },
//   {
//     id: "fa",
//     name: "xadrezfeliz",
//   },
//   {
//     id: "cv",
//     name: "washxpress",
//   },
//   {
//     id: "xy",
//     name: "depop",
//   },
//   {
//     id: "no",
//     name: "virgo",
//   },
//   {
//     id: "wr",
//     name: "walmart",
//   },
//   {
//     id: "ni",
//     name: "gojek",
//   },
//   {
//     id: "qj",
//     name: "whoosh",
//   },
//   {
//     id: "vr",
//     name: "motorkux",
//   },
//   {
//     id: "ju",
//     name: "indomaret",
//   },
//   {
//     id: "mz",
//     name: "zolushka",
//   },
//   {
//     id: "jq",
//     name: "paysafecard",
//   },
//   {
//     id: "jd",
//     name: "girabank",
//   },
//   {
//     id: "ps",
//     name: "zdorov",
//   },
//   {
//     id: "dl",
//     name: "lazada",
//   },
//   {
//     id: "kz",
//     name: "nimotv",
//   },
//   {
//     id: "gu",
//     name: "fora",
//   },
//   {
//     id: "ux",
//     name: "домовой",
//   },
//   {
//     id: "jp",
//     name: "rbt",
//   },
//   {
//     id: "bn",
//     name: "alfagift",
//   },
//   {
//     id: "kh",
//     name: "bukalapak",
//   },
//   {
//     id: "ua",
//     name: "blablacar",
//   },
//   {
//     id: "be",
//     name: "сбермегамаркет",
//   },
//   {
//     id: "cm",
//     name: "prom",
//   },
//   {
//     id: "ce",
//     name: "mosru",
//   },
//   {
//     id: "kw",
//     name: "foody",
//   },
//   {
//     id: "vl",
//     name: "ортека",
//   },
//   {
//     id: "my",
//     name: "caixa",
//   },
//   {
//     id: "ji",
//     name: "monobank",
//   },
//   {
//     id: "oi",
//     name: "tinder",
//   },
//   {
//     id: "hr",
//     name: "jkf",
//   },
//   {
//     id: "cz",
//     name: "getmega",
//   },
//   {
//     id: "zt",
//     name: "budweiser",
//   },
//   {
//     id: "ht",
//     name: "bitso",
//   },
//   {
//     id: "ul",
//     name: "getir",
//   },
//   {
//     id: "gr",
//     name: "astropay",
//   },
//   {
//     id: "wg",
//     name: "skout",
//   },
//   {
//     id: "zs",
//     name: "bilibili",
//   },
//   {
//     id: "hc",
//     name: "momo",
//   },
//   {
//     id: "cf",
//     name: "irancell",
//   },
//   {
//     id: "ku",
//     name: "royalwin",
//   },
//   {
//     id: "ll",
//     name: "888casino",
//   },
//   {
//     id: "ky",
//     name: "spatenoktoberfest",
//   },
//   {
//     id: "lh",
//     name: "24betting",
//   },
//   {
//     id: "bu",
//     name: "monobankindia",
//   },
//   {
//     id: "jc",
//     name: "ivi",
//   },
//   {
//     id: "ya",
//     name: "yandex",
//   },
//   {
//     id: "lq",
//     name: "potato",
//   },
//   {
//     id: "sc",
//     name: "voggt",
//   },
//   {
//     id: "rm",
//     name: "faberlic",
//   },
//   {
//     id: "ex",
//     name: "linode",
//   },
//   {
//     id: "zm",
//     name: "offerup",
//   },
//   {
//     id: "zi",
//     name: "lovelocal",
//   },
//   {
//     id: "kd",
//     name: "author24",
//   },
//   {
//     id: "lr",
//     name: "okta",
//   },
//   {
//     id: "nv",
//     name: "naver",
//   },
//   {
//     id: "mh",
//     name: "ашан",
//   },
//   {
//     id: "ea",
//     name: "jamesdelivery",
//   },
//   {
//     id: "yr",
//     name: "miravia",
//   },
//   {
//     id: "bz",
//     name: "blizzard",
//   },
//   {
//     id: "vo",
//     name: "brand20ua",
//   },
//   {
//     id: "xp",
//     name: "monetaru",
//   },
//   {
//     id: "lg",
//     name: "medibuddy",
//   },
//   {
//     id: "xt",
//     name: "flipkart",
//   },
//   {
//     id: "hk",
//     name: "4fun",
//   },
//   {
//     id: "yh",
//     name: "hh",
//   },
//   {
//     id: "ty",
//     name: "окей",
//   },
//   {
//     id: "wk",
//     name: "mobile01",
//   },
//   {
//     id: "qa",
//     name: "myfishka",
//   },
//   {
//     id: "ln",
//     name: "grofers",
//   },
//   {
//     id: "vn",
//     name: "yaay",
//   },
//   {
//     id: "ma",
//     name: "mail.ru",
//   },
//   {
//     id: "qz",
//     name: "faceit",
//   },
//   {
//     id: "cr",
//     name: "tenchat",
//   },
//   {
//     id: "iy",
//     name: "foodhub",
//   },
//   {
//     id: "bi",
//     name: "勇仕网络ys4fun",
//   },
//   {
//     id: "rv",
//     name: "kotak811",
//   },
//   {
//     id: "vh",
//     name: "штолле",
//   },
//   {
//     id: "bv",
//     name: "metro",
//   },
//   {
//     id: "fs",
//     name: "şikayet var",
//   },
//   {
//     id: "xg",
//     name: "fortunask",
//   },
//   {
//     id: "gx",
//     name: "hepsiburadacom",
//   },
//   {
//     id: "xz",
//     name: "paycell",
//   },
//   {
//     id: "ka",
//     name: "shopee",
//   },
//   {
//     id: "va",
//     name: "sportgully",
//   },
//   {
//     id: "ac",
//     name: "doordash",
//   },
//   {
//     id: "vs",
//     name: "winzogame",
//   },
//   {
//     id: "lt",
//     name: "bitclout",
//   },
//   {
//     id: "qo",
//     name: "moneylion",
//   },
//   {
//     id: "je",
//     name: "nanovest",
//   },
//   {
//     id: "cn",
//     name: "fiverr",
//   },
//   {
//     id: "lv",
//     name: "megogo",
//   },
//   {
//     id: "db",
//     name: "ezbuy",
//   },
//   {
//     id: "qi",
//     name: "23red",
//   },
//   {
//     id: "tp",
//     name: "indiagold",
//   },
//   {
//     id: "eg",
//     name: "contactsys",
//   },
//   {
//     id: "pb",
//     name: "skytv",
//   },
//   {
//     id: "rw",
//     name: "bls-spain",
//   },
//   {
//     id: "yj",
//     name: "ewallet",
//   },
//   {
//     id: "vp",
//     name: "kwai",
//   },
//   {
//     id: "la",
//     name: "ssoidnet",
//   },
//   {
//     id: "dt",
//     name: "delivery club",
//   },
//   {
//     id: "lf",
//     name: "tiktok/douyin",
//   },
//   {
//     id: "pz",
//     name: "lidl",
//   },
//   {
//     id: "ei",
//     name: "taksheel",
//   },
//   {
//     id: "at",
//     name: "perfluence",
//   },
//   {
//     id: "tf",
//     name: "noon",
//   },
//   {
//     id: "jb",
//     name: "wing money",
//   },
//   {
//     id: "ve",
//     name: "dream11",
//   },
//   {
//     id: "im",
//     name: "imo",
//   },
//   {
//     id: "ho",
//     name: "cathay",
//   },
//   {
//     id: "li",
//     name: "baidu",
//   },
//   {
//     id: "qk",
//     name: "bit",
//   },
//   {
//     id: "ut",
//     name: "энергобум",
//   },
//   {
//     id: "hj",
//     name: "stoloto",
//   },
//   {
//     id: "lx",
//     name: "dewupoison",
//   },
//   {
//     id: "kk",
//     name: "idealista",
//   },
//   {
//     id: "ri",
//     name: "billmill",
//   },
//   {
//     id: "xs",
//     name: "groupme",
//   },
//   {
//     id: "kp",
//     name: "hq trivia",
//   },
//   {
//     id: "js",
//     name: "golosza",
//   },
//   {
//     id: "nn",
//     name: "giftcloud",
//   },
//   {
//     id: "fl",
//     name: "rummyloot",
//   },
//   {
//     id: "ff",
//     name: "avon",
//   },
//   {
//     id: "wj",
//     name: "1хbet",
//   },
//   {
//     id: "yk",
//     name: "спортмастер",
//   },
//   {
//     id: "cx",
//     name: "icrypex",
//   },
//   {
//     id: "za",
//     name: "jdcom",
//   },
//   {
//     id: "sj",
//     name: "handypick",
//   },
//   {
//     id: "ox",
//     name: "damejidlo",
//   },
//   {
//     id: "dw",
//     name: "divar",
//   },
//   {
//     id: "do",
//     name: "leboncoin",
//   },
//   {
//     id: "ow",
//     name: "regru",
//   },
//   {
//     id: "ro",
//     name: "pingcode",
//   },
//   {
//     id: "yy",
//     name: "venmo",
//   },
//   {
//     id: "bo",
//     name: "wise",
//   },
//   {
//     id: "fb",
//     name: "facebook",
//   },
//   {
//     id: "br",
//     name: "вкусно и точка",
//   },
//   {
//     id: "ey",
//     name: "miloan",
//   },
//   {
//     id: "bf",
//     name: "keybase ",
//   },
//   {
//     id: "bh",
//     name: "uteka",
//   },
//   {
//     id: "ee",
//     name: "twilio",
//   },
//   {
//     id: "sr",
//     name: "starbucks",
//   },
//   {
//     id: "dy",
//     name: "zomato",
//   },
//   {
//     id: "vb",
//     name: "кораблик",
//   },
//   {
//     id: "un",
//     name: "humblebundle",
//   },
//   {
//     id: "xd",
//     name: "tokopedia",
//   },
//   {
//     id: "kf",
//     name: "weibo",
//   },
//   {
//     id: "rl",
//     name: "indriver",
//   },
//   {
//     id: "zz",
//     name: "dent",
//   },
//   {
//     id: "wx",
//     name: "apple",
//   },
//   {
//     id: "hz",
//     name: "drom",
//   },
//   {
//     id: "mk",
//     name: "longhu",
//   },
//   {
//     id: "ge",
//     name: "paytm",
//   },
//   {
//     id: "pp",
//     name: "huya",
//   },
//   {
//     id: "kn",
//     name: "verse",
//   },
//   {
//     id: "fh",
//     name: "lalamove",
//   },
//   {
//     id: "wd",
//     name: "casinoplus",
//   },
//   {
//     id: "se",
//     name: "feeld",
//   },
//   {
//     id: "it",
//     name: "cashapp",
//   },
//   {
//     id: "xo",
//     name: "notifire",
//   },
//   {
//     id: "yg",
//     name: "coursehero",
//   },
//   {
//     id: "oj",
//     name: "loveru",
//   },
//   {
//     id: "nu",
//     name: "stripe",
//   },
//   {
//     id: "fr",
//     name: "dana",
//   },
//   {
//     id: "tt",
//     name: "ziglu",
//   },
//   {
//     id: "xh",
//     name: "ovo",
//   },
//   {
//     id: "km",
//     name: "rozetka",
//   },
//   {
//     id: "eh",
//     name: "telegram 2.0",
//   },
//   {
//     id: "ql",
//     name: "cmtcuzdan",
//   },
//   {
//     id: "qq",
//     name: "tencent qq",
//   },
//   {
//     id: "tj",
//     name: "dbrua",
//   },
//   {
//     id: "iq",
//     name: "icq",
//   },
//   {
//     id: "rb",
//     name: "tick",
//   },
//   {
//     id: "yn",
//     name: "allegro",
//   },
//   {
//     id: "mb",
//     name: "yahoo",
//   },
//   {
//     id: "yo",
//     name: "amasia",
//   },
//   {
//     id: "cl",
//     name: "uwin",
//   },
//   {
//     id: "fo",
//     name: "mobikwik",
//   },
//   {
//     id: "fk",
//     name: "blibli",
//   },
//   {
//     id: "pc",
//     name: "casino/bet/gambling",
//   },
//   {
//     id: "wy",
//     name: "yami",
//   },
//   {
//     id: "ch",
//     name: "pocket52",
//   },
//   {
//     id: "zd",
//     name: "zilch",
//   },
//   {
//     id: "af",
//     name: "galaxywin",
//   },
//   {
//     id: "jl",
//     name: "hopi",
//   },
//   {
//     id: "kc",
//     name: "vinted",
//   },
//   {
//     id: "dg",
//     name: "mercari",
//   },
//   {
//     id: "mx",
//     name: "soulapp",
//   },
//   {
//     id: "wu",
//     name: "privetmir",
//   },
//   {
//     id: "nl",
//     name: "myntra",
//   },
//   {
//     id: "uu",
//     name: "wildberries",
//   },
//   {
//     id: "ik",
//     name: "gurubets",
//   },
//   {
//     id: "bc",
//     name: "gcash",
//   },
//   {
//     id: "vf",
//     name: "q12 trivia",
//   },
//   {
//     id: "wm",
//     name: "smo71",
//   },
//   {
//     id: "zq",
//     name: "indiaplays",
//   },
//   {
//     id: "da",
//     name: "mts cashback",
//   },
//   {
//     id: "gc",
//     name: "tradingview",
//   },
//   {
//     id: "oo",
//     name: "ligapro",
//   },
//   {
//     id: "tn",
//     name: "linkedin",
//   },
//   {
//     id: "ar",
//     name: "wondermart",
//   },
//   {
//     id: "eo",
//     name: "sizeer",
//   },
//   {
//     id: "pq",
//     name: "cdkeys",
//   },
//   {
//     id: "sl",
//     name: "сбераптека",
//   },
//   {
//     id: "wn",
//     name: "gamearena",
//   },
//   {
//     id: "hl",
//     name: "band",
//   },
//   {
//     id: "rf",
//     name: "akudo",
//   },
//   {
//     id: "hx",
//     name: "aliexpress",
//   },
//   {
//     id: "ia",
//     name: "socios",
//   },
//   {
//     id: "wz",
//     name: "foxford",
//   },
//   {
//     id: "mo",
//     name: "bumble",
//   },
//   {
//     id: "mw",
//     name: "transfergo",
//   },
//   {
//     id: "gs",
//     name: "samsungshop",
//   },
//   {
//     id: "jn",
//     name: "cloudbet",
//   },
//   {
//     id: "ti",
//     name: "cryptocom",
//   },
//   {
//     id: "bs",
//     name: "tradeup",
//   },
//   {
//     id: "bm",
//     name: "marketguru",
//   },
//   {
//     id: "cq",
//     name: "mercado",
//   },
//   {
//     id: "cj",
//     name: "dotz",
//   },
//   {
//     id: "qw",
//     name: "qiwi",
//   },
//   {
//     id: "lc",
//     name: "subito",
//   },
//   {
//     id: "nc",
//     name: "payoneer",
//   },
//   {
//     id: "re",
//     name: "coinbase",
//   },
//   {
//     id: "gl",
//     name: "globaltel",
//   },
//   {
//     id: "of",
//     name: "urent/jet/rusharing",
//   },
//   {
//     id: "lj",
//     name: "santander",
//   },
//   {
//     id: "xw",
//     name: "taki",
//   },
//   {
//     id: "gk",
//     name: "aptekaru",
//   },
//   {
//     id: "hs",
//     name: "asda",
//   },
//   {
//     id: "eq",
//     name: "qoo10",
//   },
//   {
//     id: "nz",
//     name: "foodpanda",
//   },
//   {
//     id: "sk",
//     name: "skroutz",
//   },
//   {
//     id: "mf",
//     name: "weidian",
//   },
//   {
//     id: "gz",
//     name: "lyka",
//   },
//   {
//     id: "qx",
//     name: "worldremit",
//   },
//   {
//     id: "bw",
//     name: "signal",
//   },
//   {
//     id: "bd",
//     name: "x5id",
//   },
//   {
//     id: "cd",
//     name: "spothit",
//   },
//   {
//     id: "dd",
//     name: "cloudchat",
//   },
//   {
//     id: "py",
//     name: "monese",
//   },
//   {
//     id: "uv",
//     name: "binbin",
//   },
//   {
//     id: "yb",
//     name: "система город",
//   },
//   {
//     id: "ej",
//     name: "mrq",
//   },
//   {
//     id: "dp",
//     name: "protonmail",
//   },
//   {
//     id: "ta",
//     name: "wink",
//   },
//   {
//     id: "ft",
//     name: "букмекерские",
//   },
//   {
//     id: "sh",
//     name: "vkusvill",
//   },
//   {
//     id: "ja",
//     name: "weverse",
//   },
//   {
//     id: "rk",
//     name: "fotka",
//   },
//   {
//     id: "jt",
//     name: "turkiyepetrolleri",
//   },
//   {
//     id: "tl",
//     name: "truecaller",
//   },
//   {
//     id: "xa",
//     name: "улыбкарадуги",
//   },
//   {
//     id: "hi",
//     name: "jungleerummy",
//   },
//   {
//     id: "hb",
//     name: "twitch",
//   },
//   {
//     id: "ab",
//     name: "alibaba",
//   },
//   {
//     id: "vk",
//     name: "vk.com",
//   },
//   {
//     id: "ne",
//     name: "coindcx",
//   },
//   {
//     id: "mj",
//     name: "zalo",
//   },
//   {
//     id: "yv",
//     name: "iplwin",
//   },
//   {
//     id: "jv",
//     name: "consultant",
//   },
//   {
//     id: "dm",
//     name: "iwplay",
//   },
//   {
//     id: "hh",
//     name: "uplay",
//   },
//   {
//     id: "gt",
//     name: "gett",
//   },
//   {
//     id: "pt",
//     name: "bitaqaty",
//   },
//   {
//     id: "lk",
//     name: "pureplatfrom",
//   },
//   {
//     id: "an",
//     name: "adidas",
//   },
//   {
//     id: "pf",
//     name: "pof.com",
//   },
//   {
//     id: "ml",
//     name: "apostaganha",
//   },
//   {
//     id: "qg",
//     name: "moneypay",
//   },
//   {
//     id: "pv",
//     name: "koshelek",
//   },
//   {
//     id: "hu",
//     name: "ukrnet",
//   },
//   {
//     id: "xq",
//     name: "mpl",
//   },
//   {
//     id: "jg",
//     name: "grab",
//   },
//   {
//     id: "qu",
//     name: "agroinform",
//   },
//   {
//     id: "zy",
//     name: "nttgame",
//   },
//   {
//     id: "wl",
//     name: "yougotagift",
//   },
//   {
//     id: "mg",
//     name: "magnit",
//   },
//   {
//     id: "fi",
//     name: "dundle",
//   },
//   {
//     id: "fd",
//     name: "mamba",
//   },
//   {
//     id: "uo",
//     name: "cafebazaar",
//   },
//   {
//     id: "ak",
//     name: "douyu",
//   },
//   {
//     id: "wo",
//     name: "parkplus",
//   },
//   {
//     id: "dc",
//     name: "yikyak",
//   },
//   {
//     id: "ad",
//     name: "iti",
//   },
//   {
//     id: "ov",
//     name: "beget",
//   },
//   {
//     id: "zh",
//     name: "zoho",
//   },
//   {
//     id: "co",
//     name: "rediffmail",
//   },
//   {
//     id: "vg",
//     name: "shellbox",
//   },
//   {
//     id: "pn",
//     name: "coffeelike",
//   },
//   {
//     id: "kt",
//     name: "kakaotalk",
//   },
//   {
//     id: "ws",
//     name: "indodax",
//   },
//   {
//     id: "qb",
//     name: "payberry",
//   },
//   {
//     id: "ay",
//     name: "ruten",
//   },
//   {
//     id: "qn",
//     name: "blued ",
//   },
//   {
//     id: "en",
//     name: "hermes",
//   },
//   {
//     id: "rh",
//     name: "ace2three",
//   },
//   {
//     id: "mm",
//     name: "microsoft",
//   },
//   {
//     id: "pa",
//     name: "gamekit",
//   },
//   {
//     id: "gi",
//     name: "hotline",
//   },
//   {
//     id: "bg",
//     name: "mixmart",
//   },
//   {
//     id: "qe",
//     name: "gg",
//   },
//   {
//     id: "lu",
//     name: "crickpe",
//   },
//   {
//     id: "ny",
//     name: "pyro music",
//   },
//   {
//     id: "tv",
//     name: "flink",
//   },
//   {
//     id: "pr",
//     name: "trendyol",
//   },
//   {
//     id: "aa",
//     name: "probo",
//   },
//   {
//     id: "bk",
//     name: "g2g",
//   },
//   {
//     id: "so",
//     name: "rummywealth",
//   },
//   {
//     id: "ec",
//     name: "rummyculture",
//   },
//   {
//     id: "zj",
//     name: "robinhood",
//   },
//   {
//     id: "ph",
//     name: "snappfood",
//   },
//   {
//     id: "rn",
//     name: "neftm",
//   },
//   {
//     id: "dk",
//     name: "pairs",
//   },
//   {
//     id: "us",
//     name: "irctc",
//   },
//   {
//     id: "ih",
//     name: "teenpattistarpro",
//   },
//   {
//     id: "uq",
//     name: "topdetal",
//   },
//   {
//     id: "fy",
//     name: "mylove",
//   },
//   {
//     id: "wp",
//     name: "163сom",
//   },
//   {
//     id: "yd",
//     name: "米画师mihuashi",
//   },
//   {
//     id: "xi",
//     name: "infund",
//   },
//   {
//     id: "ke",
//     name: "эльдорадо",
//   },
//   {
//     id: "uw",
//     name: "kirana",
//   },
//   {
//     id: "vz",
//     name: "hinge",
//   },
//   {
//     id: "jz",
//     name: "kaya",
//   },
//   {
//     id: "jj",
//     name: "aitu",
//   },
//   {
//     id: "rg",
//     name: "porbet",
//   },
//   {
//     id: "sv",
//     name: "dostavista",
//   },
//   {
//     id: "es",
//     name: "iqiyi",
//   },
//   {
//     id: "gd",
//     name: "surveytime",
//   },
//   {
//     id: "fc",
//     name: "pharmeasy",
//   },
//   {
//     id: "oh",
//     name: "maplesea ",
//   },
//   {
//     id: "zo",
//     name: "kaggle",
//   },
//   {
//     id: "lw",
//     name: "mrgreen",
//   },
//   {
//     id: "hp",
//     name: "meesho",
//   },
//   {
//     id: "ga",
//     name: "roposo",
//   },
//   {
//     id: "qy",
//     name: "zhihu",
//   },
//   {
//     id: "xn",
//     name: "familia",
//   },
//   {
//     id: "vv",
//     name: "seosprint",
//   },
//   {
//     id: "zw",
//     name: "quack",
//   },
//   {
//     id: "jo",
//     name: "sticpay",
//   },
//   {
//     id: "ah",
//     name: "escapefromtarkov",
//   },
//   {
//     id: "dj",
//     name: "lukoil-azs",
//   },
//   {
//     id: "qv",
//     name: "badoo",
//   },
//   {
//     id: "ru",
//     name: "hop",
//   },
//   {
//     id: "hq",
//     name: "magicbricks",
//   },
//   {
//     id: "nj",
//     name: "freshkarta",
//   },
//   {
//     id: "yf",
//     name: "citymobil",
//   },
//   {
//     id: "oe",
//     name: "codashop",
//   },
//   {
//     id: "cg",
//     name: "gemgala",
//   },
//   {
//     id: "ix",
//     name: "celcoin",
//   },
//   {
//     id: "cy",
//     name: "рса",
//   },
//   {
//     id: "uc",
//     name: "tatneft",
//   },
//   {
//     id: "wq",
//     name: "leboncoin1",
//   },
//   {
//     id: "fj",
//     name: "potato chat",
//   },
//   {
//     id: "gy",
//     name: "miyachat",
//   },
//   {
//     id: "th",
//     name: "weststein",
//   },
//   {
//     id: "kl",
//     name: "kolesa.kz",
//   },
//   {
//     id: "uz",
//     name: "offgamers",
//   },
//   {
//     id: "ls",
//     name: "careem",
//   },
//   {
//     id: "wb",
//     name: "wechat",
//   },
//   {
//     id: "gf",
//     name: "googlevoice",
//   },
//   {
//     id: "fp",
//     name: "phound",
//   },
//   {
//     id: "tx",
//     name: "bolt",
//   },
//   {
//     id: "vj",
//     name: "stormgain",
//   },
//   {
//     id: "oq",
//     name: "vlife",
//   },
//   {
//     id: "xm",
//     name: "лэтуаль",
//   },
//   {
//     id: "ed",
//     name: "gamer",
//   },
//   {
//     id: "ok",
//     name: "ok.ru",
//   },
//   {
//     id: "qf",
//     name: "redbook",
//   },
//   {
//     id: "tr",
//     name: "paysend",
//   },
//   {
//     id: "wh",
//     name: "tantan",
//   },
//   {
//     id: "vc",
//     name: "banqi",
//   },
//   {
//     id: "ns",
//     name: "oldubil",
//   },
//   {
//     id: "vi",
//     name: "viber",
//   },
//   {
//     id: "gn",
//     name: "a9a",
//   },
//   {
//     id: "ez",
//     name: "goerlifaucet",
//   },
//   {
//     id: "rr",
//     name: "wolt",
//   },
//   {
//     id: "cc",
//     name: "quipp",
//   },
//   {
//     id: "nf",
//     name: "netflix",
//   },
//   {
//     id: "sd",
//     name: "dodopizza",
//   },
//   {
//     id: "em",
//     name: "zédelivery",
//   },
//   {
//     id: "yq",
//     name: "фокстрот",
//   },
//   {
//     id: "dn",
//     name: "paxful",
//   },
//   {
//     id: "dx",
//     name: "powerkredite",
//   },
//   {
//     id: "av",
//     name: "avito",
//   },
//   {
//     id: "xu",
//     name: "recargapay",
//   },
//   {
//     id: "mp",
//     name: "winmasters",
//   },
//   {
//     id: "de",
//     name: "karusel",
//   },
//   {
//     id: "oy",
//     name: "cashfly",
//   },
//   {
//     id: "gj",
//     name: "carousell",
//   },
//   {
//     id: "wc",
//     name: "craigslist",
//   },
//   {
//     id: "ba",
//     name: "expressmoney",
//   },
//   {
//     id: "mv",
//     name: "fruitz",
//   },
//   {
//     id: "he",
//     name: "mewt",
//   },
//   {
//     id: "st",
//     name: "auchan",
//   },
//   {
//     id: "pu",
//     name: "justdating",
//   },
//   {
//     id: "df",
//     name: "happn",
//   },
//   {
//     id: "om",
//     name: "corona",
//   },
//   {
//     id: "zr",
//     name: "papara",
//   },
//   {
//     id: "fw",
//     name: "99acres",
//   },
//   {
//     id: "jy",
//     name: "sorare",
//   },
//   {
//     id: "ug",
//     name: "fiqsy",
//   },
//   {
//     id: "ii",
//     name: "cashkaro",
//   },
//   {
//     id: "vx",
//     name: "heybox",
//   },
//   {
//     id: "hd",
//     name: "marketpapa",
//   },
//   {
//     id: "vy",
//     name: "meta",
//   },
//   {
//     id: "cp",
//     name: "uklon",
//   },
//   {
//     id: "xk",
//     name: "didi",
//   },
//   {
//     id: "ib",
//     name: "immowelt",
//   },
//   {
//     id: "yi",
//     name: "yemeksepeti",
//   },
//   {
//     id: "mi",
//     name: "zupee",
//   },
//   {
//     id: "nm",
//     name: "thisshop",
//   },
//   {
//     id: "ci",
//     name: "redbus",
//   },
//   {
//     id: "pg",
//     name: "nrj music awards",
//   },
//   {
//     id: "ui",
//     name: "rutube",
//   },
//   {
//     id: "zn",
//     name: "biedronka",
//   },
//   {
//     id: "me",
//     name: "line msg",
//   },
//   {
//     id: "jf",
//     name: "likee",
//   },
//   {
//     id: "ie",
//     name: "bet365",
//   },
//   {
//     id: "sp",
//     name: "happyfresh",
//   },
// ];

export const AVAILABLE_SERVICES = {
  ef: "nextdoor",
  rx: "sheerid",
  xb: "rummyola",
  wf: "yandexgo",
  et: "clubhouse",
  sg: "ozon",
  fu: "snapchat",
  kq: "fotocasa",
  pm: "aol",
  bp: "gofundme",
  vd: "betfair",
  wv: "ais",
  qd: "taobao",
  ub: "uber",
  ev: "picpay ",
  mq: "gmng",
  jm: "mzadqatar",
  bj: "вита экспресс",
  ds: "discord",
  zv: "digikala",
  po: "premium.one",
  ry: "mcdonalds",
  lo: "oppo",
  oz: "poshmark",
  uj: "сhampionсasino",
  iz: "global24",
  ax: "crefisamais",
  mn: "rrsa",
  ol: "kazanexpress",
  od: "fwdmax",
  nr: "tosla",
  mr: "fastmail",
  pl: "perekrestok",
  su: "loco",
  qs: "мирзнакомств",
  rz: "easypay",
  xj: "сбермаркет",
  tz: "лейка",
  wa: "whatsapp",
  rc: "skype",
  ye: "zaleycash",
  cw: "paddypower",
  ha: "my11circle",
  tw: "twitter",
  ig: "instagram",
  kx: "vivo",
  nq: "trip",
  ct: "кухнянарайоне",
  ks: "hirect",
  au: "haraj",
  bx: "dosi",
  qc: "праймериз 2020",
  eu: "livescore",
  ts: "paypal",
  aq: "glovo",
  nb: "верный",
  di: "loanflix",
  ww: "bip",
  fq: "контур",
  mu: "mymusictaste",
  ue: "onet",
  md: "банки",
  el: "bisu",
  le: "e bike gewinnspiel",
  bl: "bigo live",
  cs: "agridevelop",
  ae: "myglo",
  gg: "pagsmile",
  ck: "bereal",
  yw: "grindr",
  mt: "steam",
  ai: "celebe",
  rt: "hily",
  gp: "ticketmaster",
  ic: "jogo",
  rj: "детский мир",
  yu: "xiaomi",
  uh: "yubo",
  cb: "bazos",
  fz: "kfc",
  sb: "lamoda",
  vt: "budget4me",
  tm: "akulaku",
  dv: "nobroker",
  zb: "freenow",
  sf: "sneakersnstuff",
  tc: "rambler",
  bt: "alfa",
  dq: "icecasino",
  yl: "yalla",
  qr: "mega",
  ms: "novaposhta",
  xf: "lightchat",
  fx: "pgbonus",
  fm: "touchance",
  az: "citybase",
  zk: "deliveroo",
  os: "dhani",
  aw: "taikang",
  gm: "mocospace",
  vm: "okcupid",
  jx: "swiggy",
  jr: "самокат",
  dz: "dominos pizza",
  yx: "jtexpress",
  tu: "lyft",
  uk: "airbnb",
  cu: "炙热星河",
  sz: "pivko24",
  ly: "olacabs",
  dr: "openai",
  vw: "coinfield",
  eb: "voltz",
  qm: "rosakhutor",
  ra: "keypay",
  lz: "things",
  tq: "swvl",
  kv: "rush",
  ur: "mydailycash",
  uy: "meliuz",
  nt: "sravni",
  up: "magnolia",
  xe: "galaxychat",
  er: "kwork",
  io: "здравсити",
  tg: "telegram",
  sx: "crowdtap",
  gh: "gyftr",
  ud: "disney hotstar",
  hm: "globus",
  ep: "temu",
  rq: "aptekiplus",
  sw: "ncsoft",
  fg: "indianoil",
  gq: "freelancer",
  ij: "revolut",
  du: "aubank",
  si: "cita previa",
  zu: "bigc",
  xx: "joyride",
  dh: "ebay",
  fv: "vidio",
  nh: "allobank",
  og: "okko",
  zg: "setel",
  aj: "oneaset",
  lp: "algida",
  nw: "ximalaya",
  jh: "pingpong",
  ob: "onlinerby",
  kg: "freechargeapp",
  kr: "eyecon",
  ou: "gabi",
  hn: "1688",
  yp: "payzapp",
  mc: "michat",
  bq: "adani",
  bb: "lazypay",
  we: "drugvokrug",
  nk: "gittigidiyor",
  pj: "podeli",
  am: "amazon",
  xc: "synottip",
  kj: "yappy",
  gw: "callapp",
  np: "siply",
  qt: "moneyсontrol",
  yz: "около",
  lb: "mailru group",
  px: "nifty",
  sq: "kucoinplay",
  il: "iqos",
  pw: "sellmonitor",
  gv: "humta",
  zf: "ontaxi",
  tk: "мвидео",
  rd: "lenta",
  hy: "ininal",
  um: "belwest",
  td: "chaingefinance",
  kb: "kufarby",
  vq: "ladymaria",
  rp: "hamrahaval",
  ld: "cashmine",
  sn: "olx",
  ew: "nike",
  wt: "izi",
  pd: "ifood",
  zl: "airtel",
  te: "efood",
  ym: "youla.ru",
  ki: "99app",
  fe: "cliqq",
  hw: "alipay/alibaba",
  ao: "uu163",
  ys: "zcity",
  ng: "funpay",
  sy: "brahma",
  sm: "yowin",
  ot: "any other",
  hg: "switips",
  sa: "agibank",
  jw: "br777",
  ko: "adakami",
  xl: "wmaraci",
  ca: "supers",
  qh: "oriflame",
  zx: "communitygaming",
  iu: "bykea",
  go: "google",
  iv: "inboxlv",
  gb: "youstar",
  hf: "cleartrip",
  xr: "tango",
  lm: "farpost",
  ir: "chispa",
  uf: "eneba",
  xv: "wish",
  iw: "mylavash",
  rs: "lotus",
  ip: "burger king",
  op: "miratorg",
  ss: "hezzl",
  oc: "dealshare",
  qp: "максавит",
  fa: "xadrezfeliz",
  cv: "washxpress",
  xy: "depop",
  no: "virgo",
  wr: "walmart",
  ni: "gojek",
  qj: "whoosh",
  vr: "motorkux",
  ju: "indomaret",
  mz: "zolushka",
  jq: "paysafecard",
  jd: "girabank",
  ps: "zdorov",
  dl: "lazada",
  kz: "nimotv",
  gu: "fora",
  ux: "домовой",
  jp: "rbt",
  bn: "alfagift",
  kh: "bukalapak",
  ua: "blablacar",
  be: "сбермегамаркет",
  cm: "prom",
  ce: "mosru",
  kw: "foody",
  vl: "ортека",
  my: "caixa",
  ji: "monobank",
  oi: "tinder",
  hr: "jkf",
  cz: "getmega",
  zt: "budweiser",
  ht: "bitso",
  ul: "getir",
  gr: "astropay",
  wg: "skout",
  zs: "bilibili",
  hc: "momo",
  cf: "irancell",
  ku: "royalwin",
  ll: "888casino",
  ky: "spatenoktoberfest",
  lh: "24betting",
  bu: "monobankindia",
  jc: "ivi",
  ya: "yandex",
  lq: "potato",
  sc: "voggt",
  rm: "faberlic",
  ex: "linode",
  zm: "offerup",
  zi: "lovelocal",
  kd: "author24",
  lr: "okta",
  nv: "naver",
  mh: "ашан",
  ea: "jamesdelivery",
  yr: "miravia",
  bz: "blizzard",
  vo: "brand20ua",
  xp: "monetaru",
  lg: "medibuddy",
  xt: "flipkart",
  hk: "4fun",
  yh: "hh",
  ty: "окей",
  wk: "mobile01",
  qa: "myfishka",
  ln: "grofers",
  vn: "yaay",
  ma: "mail.ru",
  qz: "faceit",
  cr: "tenchat",
  iy: "foodhub",
  bi: "勇仕网络ys4fun",
  rv: "kotak811",
  vh: "штолле",
  bv: "metro",
  fs: "şikayet var",
  xg: "fortunask",
  gx: "hepsiburadacom",
  xz: "paycell",
  ka: "shopee",
  va: "sportgully",
  ac: "doordash",
  vs: "winzogame",
  lt: "bitclout",
  qo: "moneylion",
  je: "nanovest",
  cn: "fiverr",
  lv: "megogo",
  db: "ezbuy",
  qi: "23red",
  tp: "indiagold",
  eg: "contactsys",
  pb: "skytv",
  rw: "bls-spain",
  yj: "ewallet",
  vp: "kwai",
  la: "ssoidnet",
  dt: "delivery club",
  lf: "tiktok/douyin",
  pz: "lidl",
  ei: "taksheel",
  at: "perfluence",
  tf: "noon",
  jb: "wing money",
  ve: "dream11",
  im: "imo",
  ho: "cathay",
  li: "baidu",
  qk: "bit",
  ut: "энергобум",
  hj: "stoloto",
  lx: "dewupoison",
  kk: "idealista",
  ri: "billmill",
  xs: "groupme",
  kp: "hq trivia",
  js: "golosza",
  nn: "giftcloud",
  fl: "rummyloot",
  ff: "avon",
  wj: "1хbet",
  yk: "спортмастер",
  cx: "icrypex",
  za: "jdcom",
  sj: "handypick",
  ox: "damejidlo",
  dw: "divar",
  do: "leboncoin",
  ow: "regru",
  ro: "pingcode",
  yy: "venmo",
  bo: "wise",
  fb: "facebook",
  br: "вкусно и точка",
  ey: "miloan",
  bf: "keybase ",
  bh: "uteka",
  ee: "twilio",
  sr: "starbucks",
  dy: "zomato",
  vb: "кораблик",
  un: "humblebundle",
  xd: "tokopedia",
  kf: "weibo",
  rl: "indriver",
  zz: "dent",
  wx: "apple",
  hz: "drom",
  mk: "longhu",
  ge: "paytm",
  pp: "huya",
  kn: "verse",
  fh: "lalamove",
  wd: "casinoplus",
  se: "feeld",
  it: "cashapp",
  xo: "notifire",
  yg: "coursehero",
  oj: "loveru",
  nu: "stripe",
  fr: "dana",
  tt: "ziglu",
  xh: "ovo",
  km: "rozetka",
  eh: "telegram 2.0",
  ql: "cmtcuzdan",
  qq: "tencent qq",
  tj: "dbrua",
  iq: "icq",
  rb: "tick",
  yn: "allegro",
  mb: "yahoo",
  yo: "amasia",
  cl: "uwin",
  fo: "mobikwik",
  fk: "blibli",
  pc: "casino/bet/gambling",
  wy: "yami",
  ch: "pocket52",
  zd: "zilch",
  af: "galaxywin",
  jl: "hopi",
  kc: "vinted",
  dg: "mercari",
  mx: "soulapp",
  wu: "privetmir",
  nl: "myntra",
  uu: "wildberries",
  ik: "gurubets",
  bc: "gcash",
  vf: "q12 trivia",
  wm: "smo71",
  zq: "indiaplays",
  da: "mts cashback",
  gc: "tradingview",
  oo: "ligapro",
  tn: "linkedin",
  ar: "wondermart",
  eo: "sizeer",
  pq: "cdkeys",
  sl: "сбераптека",
  wn: "gamearena",
  hl: "band",
  rf: "akudo",
  hx: "aliexpress",
  ia: "socios",
  wz: "foxford",
  mo: "bumble",
  mw: "transfergo",
  gs: "samsungshop",
  jn: "cloudbet",
  ti: "cryptocom",
  bs: "tradeup",
  bm: "marketguru",
  cq: "mercado",
  cj: "dotz",
  qw: "qiwi",
  lc: "subito",
  nc: "payoneer",
  re: "coinbase",
  gl: "globaltel",
  of: "urent/jet/rusharing",
  lj: "santander",
  xw: "taki",
  gk: "aptekaru",
  hs: "asda",
  eq: "qoo10",
  nz: "foodpanda",
  sk: "skroutz",
  mf: "weidian",
  gz: "lyka",
  qx: "worldremit",
  bw: "signal",
  bd: "x5id",
  cd: "spothit",
  dd: "cloudchat",
  py: "monese",
  uv: "binbin",
  yb: "система город",
  ej: "mrq",
  dp: "protonmail",
  ta: "wink",
  ft: "букмекерские",
  sh: "vkusvill",
  ja: "weverse",
  rk: "fotka",
  jt: "turkiyepetrolleri",
  tl: "truecaller",
  xa: "улыбкарадуги",
  hi: "jungleerummy",
  hb: "twitch",
  ab: "alibaba",
  vk: "vk.com",
  ne: "coindcx",
  mj: "zalo",
  yv: "iplwin",
  jv: "consultant",
  dm: "iwplay",
  hh: "uplay",
  gt: "gett",
  pt: "bitaqaty",
  lk: "pureplatfrom",
  an: "adidas",
  pf: "pof.com",
  ml: "apostaganha",
  qg: "moneypay",
  pv: "koshelek",
  hu: "ukrnet",
  xq: "mpl",
  jg: "grab",
  qu: "agroinform",
  zy: "nttgame",
  wl: "yougotagift",
  mg: "magnit",
  fi: "dundle",
  fd: "mamba",
  uo: "cafebazaar",
  ak: "douyu",
  wo: "parkplus",
  dc: "yikyak",
  ad: "iti",
  ov: "beget",
  zh: "zoho",
  co: "rediffmail",
  vg: "shellbox",
  pn: "coffeelike",
  kt: "kakaotalk",
  ws: "indodax",
  qb: "payberry",
  ay: "ruten",
  qn: "blued ",
  en: "hermes",
  rh: "ace2three",
  mm: "microsoft",
  pa: "gamekit",
  gi: "hotline",
  bg: "mixmart",
  qe: "gg",
  lu: "crickpe",
  ny: "pyro music",
  tv: "flink",
  pr: "trendyol",
  aa: "probo",
  bk: "g2g",
  so: "rummywealth",
  ec: "rummyculture",
  zj: "robinhood",
  ph: "snappfood",
  rn: "neftm",
  dk: "pairs",
  us: "irctc",
  ih: "teenpattistarpro",
  uq: "topdetal",
  fy: "mylove",
  wp: "163сom",
  yd: "米画师mihuashi",
  xi: "infund",
  ke: "эльдорадо",
  uw: "kirana",
  vz: "hinge",
  jz: "kaya",
  jj: "aitu",
  rg: "porbet",
  sv: "dostavista",
  es: "iqiyi",
  gd: "surveytime",
  fc: "pharmeasy",
  oh: "maplesea ",
  zo: "kaggle",
  lw: "mrgreen",
  hp: "meesho",
  ga: "roposo",
  qy: "zhihu",
  xn: "familia",
  vv: "seosprint",
  zw: "quack",
  jo: "sticpay",
  ah: "escapefromtarkov",
  dj: "lukoil-azs",
  qv: "badoo",
  ru: "hop",
  hq: "magicbricks",
  nj: "freshkarta",
  yf: "citymobil",
  oe: "codashop",
  cg: "gemgala",
  ix: "celcoin",
  cy: "рса",
  uc: "tatneft",
  wq: "leboncoin1",
  fj: "potato chat",
  gy: "miyachat",
  th: "weststein",
  kl: "kolesa.kz",
  uz: "offgamers",
  ls: "careem",
  wb: "wechat",
  gf: "googlevoice",
  fp: "phound",
  tx: "bolt",
  vj: "stormgain",
  oq: "vlife",
  xm: "лэтуаль",
  ed: "gamer",
  ok: "ok.ru",
  qf: "redbook",
  tr: "paysend",
  wh: "tantan",
  vc: "banqi",
  ns: "oldubil",
  vi: "viber",
  gn: "a9a",
  ez: "goerlifaucet",
  rr: "wolt",
  cc: "quipp",
  nf: "netflix",
  sd: "dodopizza",
  em: "zédelivery",
  yq: "фокстрот",
  dn: "paxful",
  dx: "powerkredite",
  av: "avito",
  xu: "recargapay",
  mp: "winmasters",
  de: "karusel",
  oy: "cashfly",
  gj: "carousell",
  wc: "craigslist",
  ba: "expressmoney",
  mv: "fruitz",
  he: "mewt",
  st: "auchan",
  pu: "justdating",
  df: "happn",
  om: "corona",
  zr: "papara",
  fw: "99acres",
  jy: "sorare",
  ug: "fiqsy",
  ii: "cashkaro",
  vx: "heybox",
  hd: "marketpapa",
  vy: "meta",
  cp: "uklon",
  xk: "didi",
  ib: "immowelt",
  yi: "yemeksepeti",
  mi: "zupee",
  nm: "thisshop",
  ci: "redbus",
  pg: "nrj music awards",
  ui: "rutube",
  zn: "biedronka",
  me: "line msg",
  jf: "likee",
  ie: "bet365",
  sp: "happyfresh",
};
